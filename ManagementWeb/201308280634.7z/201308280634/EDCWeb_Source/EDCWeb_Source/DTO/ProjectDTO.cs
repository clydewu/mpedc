﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EDC.DTO
{
    public class ProjectDTO
    {
        public string ProjectID { get; set; }
        public string ProjectName { get; set; }
        public string ProjectNO { get; set; }
        public string ProjectYear { get; set; }
    }
}